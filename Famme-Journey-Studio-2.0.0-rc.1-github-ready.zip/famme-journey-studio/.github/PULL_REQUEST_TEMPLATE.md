## What changed

Describe the user-facing or architectural change.

## Validation

- [ ] `npm run typecheck`
- [ ] `npm test`
- [ ] `npm run build`
- [ ] No company-specific or confidential data added to public core
- [ ] Workspace/data migrations considered if the schema changed
- [ ] Keyboard and reduced-motion behavior checked where relevant
